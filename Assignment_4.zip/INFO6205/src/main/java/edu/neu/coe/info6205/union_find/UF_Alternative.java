package edu.neu.coe.info6205.union_find;

import java.util.Random;
import java.util.function.Supplier;

import edu.neu.coe.info6205.util.Benchmark_Timer;

public class UF_Alternative {
	public static void main(String[] args) {
		int repeat = 6;
		int n = 10000;
		int nr = n;
		
		Benchmark_Timer<Weighted_UF> benchmarkWUFSize = new Benchmark_Timer<Weighted_UF>("Benchmark for Weighted UF based on size",null, (a) -> count(a) ,null);
        Benchmark_Timer<UF_HWQUPC> benchmarkWUFHeight = new Benchmark_Timer<UF_HWQUPC>("Benchmark for Weighted UF based on height",null, (a) -> count(a) ,null);
        Benchmark_Timer<Weighted_UF> benchmarkWUFPathCompression = new Benchmark_Timer<Weighted_UF>("Benchmark for Weighted UF Path compression ",null, (a) -> count(a) ,null);
        Benchmark_Timer<Weighted_UF> benchmarkWUFPathCompressionIntermediate = new Benchmark_Timer<Weighted_UF>("Benchmark for Weighted UF Path compression Grandparent fix",null, (a) -> count(a) ,null);
        
        for(int i = 0; i<repeat;i++){
        	
            final int el = n;

            Supplier<Weighted_UF> WUFsize = () -> new Weighted_UF(el, false, false);
            double random_time = benchmarkWUFSize.runFromSupplier(WUFsize, 20);
            System.out.println("Time taken: " + random_time + "ms");           

            Supplier<UF_HWQUPC> WUFheight = () -> new UF_HWQUPC(el, false);
            random_time = benchmarkWUFHeight.runFromSupplier(WUFheight, 20);
            System.out.println("Time taken: " + random_time + "ms");

            Supplier<Weighted_UF> WUFPC2pass = () -> new Weighted_UF(el, true, false);
            random_time = benchmarkWUFPathCompression.runFromSupplier(WUFPC2pass, 20);
            System.out.println("Time taken: " + random_time + "ms");

            Supplier<Weighted_UF> WUFPC1pass = () -> new Weighted_UF(el, true, true);
            random_time = benchmarkWUFPathCompressionIntermediate.runFromSupplier(WUFPC1pass, 20);
            System.out.println("Time taken: " + random_time + "ms");

            n *= 2;
        }
        
        n = nr;
        
        for(int i=0; i<repeat; i++){
        	Weighted_UF wufSize          = new Weighted_UF(n, false, false);
            UF_HWQUPC   wufHeight        = new UF_HWQUPC(n, false);
            Weighted_UF wufPC            = new Weighted_UF(n, true, false);
            Weighted_UF wufPCGrandparent = new Weighted_UF(n, true, true);

            count(wufSize);
            count(wufHeight);
            count(wufPC);
            count(wufPCGrandparent);

            System.out.println("Depth_Size and n = " + n + " is = " +wufSize.finalDepth());
            System.out.println("Depth_Height and n = " + n + " is = " +wufHeight.finalDepth());
            System.out.println("Depth_CP and n = " + n + " is = " +wufPC.finalDepth());
            System.out.println("Depth_CP with Grandparent Fix and n = " + n + " is = " +wufPCGrandparent.finalDepth());
            n = n*2;
        }
               
	}
	
	public static int count(UF_HWQUPC quickfind) {
        int n = quickfind.components();
        Random r = new Random();
        int pairs = 0;

        while(quickfind.components() != 1){
            int p = r.nextInt(n);
            int q = r.nextInt(n);
            pairs++;
            if(!quickfind.connected(p,q)) {
                quickfind.union(p, q);
            }
        }

        return pairs;
    }
	
	public static int count(Weighted_UF quickfind) {
        int n = quickfind.count();
        Random r = new Random();
        int pairs = 0;

        while(quickfind.count() != 1){
            int p = r.nextInt(n);
            int q = r.nextInt(n);
            pairs++;
            if(!quickfind.connected(p,q)) {
                quickfind.union(p, q);
            }
        }

        return pairs;
    }

}
