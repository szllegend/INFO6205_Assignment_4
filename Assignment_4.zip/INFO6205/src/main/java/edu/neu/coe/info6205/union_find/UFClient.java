package edu.neu.coe.info6205.union_find;

import java.util.Random;

public class UFClient {
	
	public static int count(int n) {
		
		UF_HWQUPC uf_hwqupc = new UF_HWQUPC(n,true);
		Random r = new Random();
		
		int pairs = 0;
		
		while(uf_hwqupc.components() != 1) {
			int r1 = r.nextInt(n);
			int r2 = r.nextInt(n);
			pairs++;
			if(!uf_hwqupc.connected(r1, r2)) {
				uf_hwqupc.union(r1, r2);
			}
		}
		
		return pairs;
	}
	
	public static void main(String[] args) {
		
		int n = 10001;
		int start = 0;
		int re = 200;
		
		for(int i = start; i < n; i = i + 500) {
			int ret = 0;
			for(int j = 0; j < re; j++) {
				if(i != 0) {
					ret += count(i);
				}
				else {
					ret += count(1);
									
				}
			}
			
			double retd = ret/re;
			double log = 0.53 * Math.log(i) * i;
			//System.out.println(i);
			//System.out.println(retd);
			System.out.println("For n = " + i + " average number of pairs generated over 200 runs were = " + retd);
			double slope = retd/i;
			//System.out.println("The slope is " + slope);
			//System.out.println(slope);
		
			
		}
		
	}

}
